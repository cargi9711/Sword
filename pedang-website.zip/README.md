# Koleksi Pedang Dunia

Website sederhana bertema pedang dari berbagai budaya di dunia.

## Fitur
- Halaman Home
- Daftar Pedang
- Desain gelap (dark theme)

## Cara Menjalankan
Buka file `index.html` di browser.
